CAMPUZANO CABOT, SERGI

DABRIO RAMÍREZ, RUBEN

GUO, HAOBIN

RICCI PUJOL, LORENZO

sergi.campuzano@estudiantat.upc.edu

ruben.dabrio@estudiantat.upc.edu

haobin.guo@estudiantat.upc.edu

lorenzo.ricci@estudiantat.upc.edu
