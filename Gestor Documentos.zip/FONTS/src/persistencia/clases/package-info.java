/**
 * Contiene todas las clases necessarias en la capa de persistencia
 */
package persistencia.clases;