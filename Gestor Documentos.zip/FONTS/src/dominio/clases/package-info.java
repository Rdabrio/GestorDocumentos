/**
 * Contiene todas las clases necessarias en la capa de dominio
 */
package dominio.clases;